package com.gl.labwk15d01dem2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Labwk15d01dem2Application {

	public static void main(String[] args) {
		SpringApplication.run(Labwk15d01dem2Application.class, args);
	}

}
