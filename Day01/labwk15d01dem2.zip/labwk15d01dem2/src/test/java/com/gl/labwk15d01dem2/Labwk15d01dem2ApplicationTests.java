package com.gl.labwk15d01dem2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Labwk15d01dem2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
