package com.greatlearning.libmgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibmgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
