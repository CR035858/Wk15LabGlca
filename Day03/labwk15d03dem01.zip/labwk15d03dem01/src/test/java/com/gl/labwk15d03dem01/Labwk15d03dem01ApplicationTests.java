package com.gl.labwk15d03dem01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Labwk15d03dem01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
