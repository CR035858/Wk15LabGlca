package com.gl.labwk15d03dem01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Labwk15d03dem01Application {

	public static void main(String[] args) {
		SpringApplication.run(Labwk15d03dem01Application.class, args);
		System.out.println("Welcome to SpringBoot JPA App....");
	}

}
