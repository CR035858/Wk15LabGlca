package com.gl.labwk15d03dem01.service;

import java.util.List;

import com.gl.labwk15d03dem01.model.CCRepDetails;



public interface CCRepDetailService {
	
	public List<CCRepDetails> getAllCCRepDetails();
	
}
