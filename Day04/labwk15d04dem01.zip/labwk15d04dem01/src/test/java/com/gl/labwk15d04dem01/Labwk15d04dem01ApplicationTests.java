package com.gl.labwk15d04dem01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Labwk15d04dem01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
