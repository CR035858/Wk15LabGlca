package com.gl.labwk15d04dem01.service;

import java.util.List;

import com.gl.labwk15d04dem01.model.CCRepDetails;



public interface CCRepDetailService {
	
	public List<CCRepDetails> getAllCCRepDetails();
	public void saveCCRepDetail(CCRepDetails ccRepDetail);
	public void deleteCCRepById(int id);
	public CCRepDetails getCCRepById(int id);

}
