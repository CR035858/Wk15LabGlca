package com.gl.labwk15d04dem01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Labwk15d04dem01Application {

	public static void main(String[] args) {
		SpringApplication.run(Labwk15d04dem01Application.class, args);
		System.out.println("Welcome to SpringBoot JPA App....");
	}

}
